# Disable fancy log messages.
FANCYTTY=0
