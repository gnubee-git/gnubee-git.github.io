CREATE TABLE table_name (
	 field_1 INT(10) NOT NULL,
	 field_2 VARCHAR(20),
	 field_4 TEXT
)
