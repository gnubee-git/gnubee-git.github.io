CREATE SCHEMA schema_name
	[ AUTHORIZATION user_name ]
	[ schema_element [ ... ] ]